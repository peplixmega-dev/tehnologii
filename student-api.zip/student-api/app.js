const connect = require('./src/database');
const createApp = require('./src/app');
async function main() {
  const repo = await connect();
  const server = createApp(repo).listen(process.env.PORT || 3000, () => console.log('Сервер запущен на порту ' + (process.env.PORT || 3000)));
  server.on('error', async () => { console.error('Не удалось запустить HTTP-сервер'); await repo.close(); process.exitCode = 1; });
  let stopping = false;
  const stop = () => {
    if (stopping) return;
    stopping = true;
    server.close(async () => { await repo.close(); });
  };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
main().catch(() => { console.error('Не удалось подключиться к БД. Проверьте .env и запуск базы.'); process.exitCode = 1; });
