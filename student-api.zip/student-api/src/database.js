require('dotenv').config();
module.exports = function connect() {
  const driver = process.env.DB_DRIVER || 'postgres';
  if (!['postgres', 'mongo'].includes(driver)) throw new Error('DB_DRIVER должен быть postgres или mongo');
  return require(`./repositories/${driver}`)();
};
