const express = require('express');
const fail = (status, message) => Object.assign(new Error(message), { status });
function validate(body, partial) {
  const limits = { name: 100, email: 254, group_name: 50 };
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw fail(400, 'Ожидается JSON-объект');
  const keys = Object.keys(body);
  if (!keys.length || keys.some(key => !Object.hasOwn(limits, key))) throw fail(400, 'Передайте только name, email, group_name');
  if (!partial && Object.keys(limits).some(key => !Object.hasOwn(body, key))) throw fail(400, 'Обязательны name, email, group_name');
  const data = {};
  for (const key of keys) {
    if (typeof body[key] !== 'string' || !body[key].trim() || body[key].trim().length > limits[key]) throw fail(400, `Некорректное поле ${key}`);
    data[key] = body[key].trim();
  }
  if (data.email) {
    data.email = data.email.toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) throw fail(400, 'Некорректный email');
  }
  return data;
}
module.exports = function createApp(repo, log = console.log) {
  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    const start = Date.now();
    const date = new Date().toISOString();
    res.on('finish', () => log(`${date} ${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - start}ms`));
    next();
  });
  app.use(express.json({ limit: '16kb' }));
  app.get('/', (req, res) => res.json({ message: 'API студентов', endpoint: '/api/students' }));
  const router = express.Router();
  router.param('id', (req, res, next, id) => {
    if (!repo.validId(id)) return next(fail(400, 'Некорректный id'));
    next();
  });
  router.get('/', async (req, res) => {
    const group = req.query.group;
    if (group !== undefined && (typeof group !== 'string' || !group.trim() || group.length > 50)) throw fail(400, 'Некорректная группа');
    res.json(await repo.list(group));
  });
  router.get('/:id', async (req, res) => {
    const student = await repo.get(req.params.id);
    if (!student) throw fail(404, 'Студент не найден');
    res.json(student);
  });
  router.post('/', async (req, res) => {
    const student = await repo.create(validate(req.body, false));
    res.location(`/api/students/${student.id}`).status(201).json(student);
  });
  for (const method of ['put', 'patch']) {
    router[method]('/:id', async (req, res) => {
      const student = await repo.update(req.params.id, validate(req.body, method === 'patch'), method === 'put');
      if (!student) throw fail(404, 'Студент не найден');
      res.json(student);
    });
  }
  router.delete('/:id', async (req, res) => {
    if (!await repo.remove(req.params.id)) throw fail(404, 'Студент не найден');
    res.status(204).end();
  });
  app.use('/api/students', router);
  app.use((req, res, next) => next(fail(404, 'Маршрут не найден')));
  app.use((err, req, res, next) => {
    if (res.headersSent) return next(err);
    if (err.code === '23505' || err.code === 11000) return res.status(409).json({ error: 'Этот email уже используется' });
    const status = err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error('Ошибка сервера:', err.code || err.name);
    const message = err.type === 'entity.parse.failed' ? 'Некорректный JSON' : err.type === 'entity.too.large' ? 'Слишком большой запрос' : err.message;
    res.status(status).json({ error: status === 500 ? 'Внутренняя ошибка сервера' : message });
  });
  return app;
};
