const { Pool } = require('pg');
module.exports = async function connect() {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  try { await pool.query('SELECT 1'); } catch (e) { await pool.end(); throw e; }
  return {
    validId: id => /^[1-9]\d*$/.test(id) && Number(id) <= 2147483647,
    async list(group) {
      const result = await pool.query('SELECT * FROM students' +
        (group ? ' WHERE group_name = $1' : '') + ' ORDER BY id', group ? [group] : []);
      return result.rows;
    },
    async get(id) { return (await pool.query('SELECT * FROM students WHERE id=$1', [id])).rows[0]; },
    async create(data) {
      return (await pool.query('INSERT INTO students (name,email,group_name) VALUES ($1,$2,$3) RETURNING *',
        [data.name, data.email, data.group_name])).rows[0];
    },
    async update(id, data) {
      // Имена колонок берутся только из фиксированного списка; значения параметризованы.
      const keys = ['name', 'email', 'group_name'].filter(key => Object.hasOwn(data, key));
      const sets = keys.map((key, i) => `${key}=$${i + 1}`).join(',');
      return (await pool.query(`UPDATE students SET ${sets} WHERE id=$${keys.length + 1} RETURNING *`,
        [...keys.map(key => data[key]), id])).rows[0];
    },
    async remove(id) { return (await pool.query('DELETE FROM students WHERE id=$1', [id])).rowCount > 0; },
    close: () => pool.end()
  };
};
