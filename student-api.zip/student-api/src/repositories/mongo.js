const { MongoClient, ObjectId } = require('mongodb');
module.exports = async function connect() {
  const client = new MongoClient(process.env.MONGODB_URI);
  try {
    await client.connect();
    const db = client.db(process.env.MONGODB_DB || 'university');
    try {
      await db.createCollection('students', { validator: { $jsonSchema: {
        bsonType: 'object', required: ['name', 'email', 'group_name'],
        properties: {
          name: { bsonType: 'string', minLength: 1, maxLength: 100 },
          email: { bsonType: 'string', minLength: 3, maxLength: 254 },
          group_name: { bsonType: 'string', minLength: 1, maxLength: 50 }
        }
      } } });
    } catch (e) { if (e.code !== 48) throw e; }
    const students = db.collection('students');
    await students.createIndex({ email: 1 }, { unique: true });
    const serialize = doc => doc ? { id: doc._id.toHexString(), name: doc.name, email: doc.email, group_name: doc.group_name } : null;
    return {
      validId: id => /^[a-fA-F0-9]{24}$/.test(id),
      async list(group) { return (await students.find(group ? { group_name: group } : {}).sort({ _id: 1 }).toArray()).map(serialize); },
      async get(id) { return serialize(await students.findOne({ _id: new ObjectId(id) })); },
      async create(data) {
        const result = await students.insertOne({ ...data });
        return { id: result.insertedId.toHexString(), ...data };
      },
      async update(id, data, replace) {
        const filter = { _id: new ObjectId(id) };
        const options = { returnDocument: 'after', includeResultMetadata: false };
        return serialize(replace
          ? await students.findOneAndReplace(filter, data, options)
          : await students.findOneAndUpdate(filter, { $set: data }, options));
      },
      async remove(id) { return (await students.deleteOne({ _id: new ObjectId(id) })).deletedCount > 0; },
      close: () => client.close()
    };
  } catch (e) { await client.close(); throw e; }
};
