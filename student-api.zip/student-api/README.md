# Практическая работа: REST API студентов

Выполнены задания 1–6 лекции 8–9. Приложение запускается на порту 3000, работает с PostgreSQL или MongoDB. Обе базы используют одинаковые маршруты; данные между ними не синхронизируются. Исходный PDF менять не требуется.

## Запуск

Нужны Node.js 22+ с npm и Docker с Compose. Учебные пароли в примере предназначены только для локального запуска.

```bash
cd student-api
npm install
cp .env.example .env
docker compose up -d
```

Дождитесь готовности БД (обычно несколько секунд; журнал: `docker compose logs`). Затем:

```bash
npm run seed
npm start
```

Откройте http://localhost:3000/api/students. Начальные записи: Айдана, Данияр, Алия. Повторное наполнение пропускает совпадающие email.

Для MongoDB остановите Node.js через Ctrl+C, укажите `DB_DRIVER=mongo` в `.env`, снова выполните `npm run seed` и `npm start`. Коллекция, схема валидации и уникальный индекс email создаются при подключении. Для возврата к PostgreSQL укажите `DB_DRIVER=postgres`.

Если Docker не используется, запустите установленные PostgreSQL/MongoDB, настройте строки подключения в `.env` и выполните `sql/init.sql` в базе PostgreSQL. В Compose SQL выполняется автоматически только при первом создании тома PostgreSQL.

Остановка контейнеров: `docker compose down`. Данные сохраняются в томах.

## Маршруты

| Метод | Путь | Успех | Назначение |
|---|---|---|---|
| GET | /api/students | 200 | Список, фильтр `?group=IT-23` |
| GET | /api/students/:id | 200 | Один студент |
| POST | /api/students | 201 + Location | Создание |
| PUT | /api/students/:id | 200 | Замена всех трёх полей |
| PATCH | /api/students/:id | 200 | Изменение переданных полей |
| DELETE | /api/students/:id | 204 без тела | Удаление |

Ошибки: 400 — некорректные данные/id/JSON; 404 — запись или маршрут не найдены; 409 — email занят; 413 — тело больше 16 КБ; 500 — внутренняя ошибка. Ошибки возвращаются в формате `{"error":"Описание"}`.

Поля: `name` (1–100 символов), `email` (до 254, базовая проверка формата), `group_name` (1–50). Пробелы по краям удаляются, email приводится к нижнему регистру. POST и PUT требуют все три поля; PATCH — минимум одно. Неизвестные поля запрещены. В PostgreSQL id — положительное целое число, в MongoDB — строка из 24 шестнадцатеричных символов. Для MongoDB используйте id из ответа POST/GET.

## Примеры проверки

```bash
curl http://localhost:3000/api/students
curl 'http://localhost:3000/api/students?group=IT-23'
curl -i -X POST http://localhost:3000/api/students \
  -H 'Content-Type: application/json' \
  -d '{"name":"Марат","email":"marat@example.com","group_name":"IT-25"}'
```

Скопируйте `id` созданного студента в переменную (ниже 4 — пример для PostgreSQL после наполнения):

```bash
ID=4
curl -i "http://localhost:3000/api/students/$ID"
curl -i -X PUT "http://localhost:3000/api/students/$ID" \
  -H 'Content-Type: application/json' \
  -d '{"name":"Марат Алиев","email":"marat@example.com","group_name":"IT-26"}'
curl -i -X PATCH "http://localhost:3000/api/students/$ID" \
  -H 'Content-Type: application/json' -d '{"group_name":"IT-27"}'
curl -i -X DELETE "http://localhost:3000/api/students/$ID"
curl -i "http://localhost:3000/api/students/$ID"
```

Последний запрос возвращает 404. Повторите последовательность при `DB_DRIVER=mongo`, подставив MongoDB id. Так проверяются поиск, добавление, обновление и удаление документов.

## Структура и соответствие заданиям

- Задание 1: `package.json`, `app.js` — зависимости и запуск.
- Задание 2: `src/app.js` — Router, шесть маршрутов и HTTP-статусы.
- Задание 3: middleware в `src/app.js` — дата/время, метод, URL, статус, длительность в миллисекундах. Запись происходит при событии `finish` ответа, включая ответы с ошибками.
- Задание 4: `sql/init.sql`, `src/repositories/postgres.js` — таблица, пул pg, параметризованный CRUD.
- Задание 5: `src/repositories/mongo.js`, `scripts/seed.js` — коллекция, начальные документы и CRUD.
- Задание 6: `REPORT.md` — сравнение БД.

Маршруты отделены от доступа к БД. Общая проверка данных используется обоими хранилищами. PUT передаёт все поля, PATCH — только изменяемые; PostgreSQL обновляет поля одним запросом, MongoDB использует замену документа для PUT и `$set` для PATCH. Подключение к БД переиспользуется.

## Автоматические проверки

```bash
npm test
```

Тест проверяет HTTP API через настоящее Express-приложение с тестовым хранилищем в памяти: CRUD, статусы, нормализацию email, дубликаты, фильтрацию, неверный JSON, валидацию и логирование. Он не заменяет проверку с реальными PostgreSQL/MongoDB. Результаты проведённых проверок — `VERIFICATION.md`.

## Документация

- [Express: обработка ошибок](https://expressjs.com/en/5x/guide/error-handling/)
- [node-postgres: параметризованные запросы](https://node-postgres.com/features/queries)
- [MongoDB: обновление документов](https://www.mongodb.com/docs/drivers/node/current/crud/update/modify/)
