const connect = require('../src/database');
async function main() {
  const repo = await connect();
  try {
    for (const student of [
      { name: 'Айдана', email: 'aidana@example.com', group_name: 'IT-23' },
      { name: 'Данияр', email: 'daniyar@example.com', group_name: 'IT-24' },
      { name: 'Алия', email: 'aliya@example.com', group_name: 'IT-23' }
    ]) {
      try { console.log(await repo.create(student)); }
      catch (e) { if (e.code !== '23505' && e.code !== 11000) throw e; }
    }
  } finally { await repo.close(); }
}
main().catch(() => { console.error('Ошибка наполнения БД: проверьте подключение и схему'); process.exitCode = 1; });
