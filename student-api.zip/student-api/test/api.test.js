const { test } = require('node:test');
const assert = require('node:assert/strict');
const createApp = require('../src/app');
// Изолированная проверка HTTP-контракта; это не интеграционный тест БД.
function memoryRepo() {
  let seq = 0;
  const rows = new Map();
  function unique(data, id) {
    if ([...rows.values()].some(row => row.email === data.email && row.id !== id)) throw Object.assign(new Error(), { code: '23505' });
  }
  return {
    validId: id => /^[1-9]\d*$/.test(id),
    list: async group => [...rows.values()].filter(row => !group || row.group_name === group),
    get: async id => rows.get(Number(id)),
    create: async data => { unique(data); const row = { id: ++seq, ...data }; rows.set(row.id, row); return row; },
    update: async (id, data) => { id = Number(id); if (!rows.has(id)) return null; unique(data, id); const row = { ...rows.get(id), ...data }; rows.set(id, row); return row; },
    remove: async id => rows.delete(Number(id))
  };
}
test('CRUD, validation, statuses, filtering and logging', async t => {
  const logs = [];
  const server = createApp(memoryRepo(), line => logs.push(line)).listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  const base = `http://127.0.0.1:${server.address().port}/api/students`;
  async function request(method, path = '', body) {
    return fetch(base + path, { method, headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
  }
  const original = { name: 'Айдана', email: 'AIDANA@example.com', group_name: 'IT-23' };
  assert.deepEqual(await (await request('GET')).json(), []);
  let response = await request('POST', '', original);
  assert.equal(response.status, 201);
  assert.equal(response.headers.get('location'), '/api/students/1');
  assert.equal((await response.json()).email, 'aidana@example.com');
  assert.equal((await request('POST', '', original)).status, 409);
  assert.equal((await request('GET', '/1')).status, 200);
  assert.equal((await (await request('GET', '?group=IT-23')).json()).length, 1);
  assert.deepEqual(await (await request('GET', '?group=IT-24')).json(), []);
  assert.equal((await request('PUT', '/1', { name: 'Алия' })).status, 400);
  response = await request('PATCH', '/1', { name: 'Алия' });
  assert.equal(response.status, 200);
  assert.equal((await response.json()).group_name, 'IT-23');
  response = await request('PUT', '/1', { name: 'Данияр', email: 'd@example.com', group_name: 'IT-24' });
  assert.equal(response.status, 200);
  assert.equal((await response.json()).group_name, 'IT-24');
  for (const body of [{}, [], { ...original, email: 'wrong' }, { ...original, id: 9 }, { ...original, name: '  ' }, { ...original, group_name: 12 }]) {
    assert.equal((await request('POST', '', body)).status, 400);
  }
  assert.equal((await request('GET', '/invalid')).status, 400);
  assert.equal((await request('GET', '?group=a&group=b')).status, 400);
  for (const method of ['GET', 'PUT', 'PATCH', 'DELETE']) {
    assert.equal((await request(method, '/999', ['PUT', 'PATCH'].includes(method) ? original : undefined)).status, 404);
  }
  assert.equal((await fetch(base, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad' })).status, 400);
  response = await request('DELETE', '/1');
  assert.equal(response.status, 204);
  assert.equal(await response.text(), '');
  assert.equal((await request('GET', '/1')).status, 404);
  assert.ok(logs.some(line => /POST \/api\/students 201 \d+ms$/.test(line)));
});
